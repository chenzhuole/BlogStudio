const badWords = ["SB", "sb", "sB", "Sb", "tm", "cnm", "草泥马", "去你妈妈的", "有病", "神经", "操他妈的", "弱智"];

function containsBadWords(text) {
    return badWords.some((word) => text.includes(word));
}
function changeBackgroundColor(color) {
    document.body.style.backgroundColor = color;
    document.body.style.backgroundImage = 'none';
    localStorage.setItem('backgroundColor', color);
    localStorage.removeItem('backgroundImage'); // 移除之前的背景图片
}

function changeBackgroundImage(url) {
    document.body.style.backgroundImage = `url(${url})`;
    document.body.style.backgroundColor = 'transparent';
    localStorage.setItem('backgroundImage', url);
    localStorage.removeItem('backgroundColor'); // 移除之前的背景颜色
}

function resetDefaultBackground() {
    const defaultColor = 'rgb(205, 205, 205)';
    document.body.style.backgroundColor = defaultColor;
    document.body.style.backgroundImage = 'none';
    localStorage.removeItem('backgroundColor');
    localStorage.removeItem('backgroundImage');
}

window.onload = function() {
    const savedColor = localStorage.getItem('backgroundColor');
    const savedImage = localStorage.getItem('backgroundImage');
    if (savedColor) {
        document.body.style.backgroundColor = savedColor;
    } else if (savedImage) {
        document.body.style.backgroundImage = `url(${savedImage})`;
        document.body.style.backgroundColor = 'transparent';
    }
}

function submitPost() {
    const type = document.getElementById('postType').value;
    const title = document.getElementById('postTitle').value.trim();
    const content = document.getElementById('postContent').value.trim();
    const username = localStorage.getItem('username') || "匿名用户"; // 从localStorage获取用户名，默认为"匿名用户"
    const messageElement = document.getElementById('message');

    if (containsBadWords(title) || containsBadWords(content)) {
        messageElement.textContent = "不能发送不良信息！";
        return;
    }

    if (title === "" || content === "") {
        messageElement.textContent = "题目和内容不能为空！";
        return;
    }

    const time = new Date();
    const formattedTime = time.toLocaleString();

    const posts = JSON.parse(localStorage.getItem('posts')) || [];
    posts.push({ title, content, time: formattedTime, username, type, replies: [], likes: 0, hasLiked: false });
    localStorage.setItem('posts', JSON.stringify(posts));

    document.getElementById('postTitle').value = "";
    document.getElementById('postContent').value = "";

    displayPosts();
    messageElement.textContent = "帖子发布成功！";
}

function toggleLikePost(index) {
    const posts = JSON.parse(localStorage.getItem('posts'));
    if (!posts[index].hasLiked) {
        posts[index].likes++;
        posts[index].hasLiked = true; // 设置为已点赞
    } else {
        posts[index].likes--;
        posts[index].hasLiked = false; // 撤销点赞
    }
    localStorage.setItem('posts', JSON.stringify(posts));
    displayPosts();
}
function changeBackgroundColor(color) {
    console.log(`设置背景颜色: ${color}`); // 调试输出
    document.body.style.backgroundColor = color;
    document.body.style.backgroundImage = 'none';
    localStorage.setItem('backgroundColor', color);
    localStorage.removeItem('backgroundImage'); // 移除之前的背景图片
}

function changeBackgroundImage(url) {
    console.log(`设置背景图片: ${url}`); // 调试输出
    document.body.style.backgroundImage = `url(${url})`;
    document.body.style.backgroundColor = 'transparent';
    localStorage.setItem('backgroundImage', url);
    localStorage.removeItem('backgroundColor'); // 移除之前的背景颜色
}

function resetDefaultBackground() {
    console.log("重置为默认背景"); // 调试输出
    const defaultColor = 'rgb(205, 205, 205)';
    document.body.style.backgroundColor = defaultColor;
    document.body.style.backgroundImage = 'none';
    localStorage.removeItem('backgroundColor');
    localStorage.removeItem('backgroundImage');
}

window.onload = function() {
    const savedColor = localStorage.getItem('backgroundColor');
    const savedImage = localStorage.getItem('backgroundImage');
    if (savedColor) {
        document.body.style.backgroundColor = savedColor;
        console.log(`恢复背景颜色: ${savedColor}`); // 调试输出
    } else if (savedImage) {
        document.body.style.backgroundImage = `url(${savedImage})`;
        document.body.style.backgroundColor = 'transparent';
        console.log(`恢复背景图片: ${savedImage}`); // 调试输出
    }
}


function displayPosts(filteredPosts = null) {
    const postsList = document.getElementById('postsList');
    postsList.innerHTML = "";

    const posts = filteredPosts || JSON.parse(localStorage.getItem('posts')) || [];
    posts.forEach((post, index) => {
        const postElement = document.createElement('div');
        postElement.innerHTML = `
            <h3>${post.title} (${post.type})</h3>
            <p>作者: ${post.username}</p>
            <p>${post.content}</p>
            <p><small>时间: ${post.time}</small></p>
            <button class="pn like-button" onclick="toggleLikePost(${index})">👍 ${post.likes}</button>
            <button class="pn" onclick="document.getElementById('replyInput-${index}').style.display='block';">回复</button>
            <div class="reply" id="replyInput-${index}">
                <textarea placeholder="请输入回复内容" rows="3"></textarea>
                <button class="pn" onclick="replyPost(${index})">提交回复</button>
            </div>
            <div class="replies">`;

        // 显示每个帖子的回复
        post.replies.forEach((reply, replyIndex) => {
            postElement.innerHTML += `
                <p><strong>${reply.username}:</strong> ${reply.content} <small>(${reply.time})</small>
                <button class="like-button" onclick="likeReply(${index}, ${replyIndex})">👍 ${reply.likes}</button></p>`;
        });

        postElement.innerHTML += `</div></div>`;
        postsList.appendChild(postElement);
    });
}

function searchPosts() {
    const searchTerm = document.getElementById('searchInput').value.trim().toLowerCase();
    const posts = JSON.parse(localStorage.getItem('posts')) || [];
    const filteredPosts = posts.filter(post =>
        post.title.toLowerCase().includes(searchTerm) ||
        post.content.toLowerCase().includes(searchTerm) ||
        post.type.toLowerCase().includes(searchTerm) // 也可以通过类型进行搜索
    );
    displayPosts(filteredPosts);
}

// 页面加载时显示已发布的帖子
window.onload = displayPosts;
window.onload = function() {
    const pageHeight = document.body.scrollHeight;
    document.body.style.backgroundImage = `url('your-image.jpg')`;
    document.body.style.backgroundSize = `cover`;
    document.body.style.backgroundRepeat = `no-repeat`;
    document.body.style.backgroundPosition = `center`;
    document.body.style.height = `${pageHeight}px`;
};
// 从 Local Storage 获取用户信息
const users = JSON.parse(localStorage.getItem('users')) || [];

function authenticate(username, password) {
    return users.some(user => user.username === username && user.password === password);
}

function login() {
    const username = document.getElementById('usernameInput').value.trim();
    const password = document.getElementById('passwordInput').value.trim();
    const messageElement = document.getElementById('message');

    if (username === "" || password === "") {
        messageElement.textContent = "用户名和密码不能为空！";
        return;
    }

    if (authenticate(username, password)) {
        messageElement.textContent = "登录成功！";
        window.location.href = 'home.html'; // 登录成功后跳转到 page2.html
    } else {
        messageElement.textContent = "用户名或密码不正确，请重试。";
    }
}

function register() {
    const username = document.getElementById('usernameInput').value.trim();
    const password = document.getElementById('passwordInput').value.trim();
    const messageElement = document.getElementById('message');

    if (username === "" || password === "") {
        messageElement.textContent = "用户名和密码不能为空！";
        return;
    }

    // 检查用户是否已存在
    if (users.some(user => user.username === username)) {
        messageElement.textContent = "用户名已存在，请选择其他用户名。";
        return;
    }

    // 将新用户添加到 users 数组
    users.push({ username, password });
    localStorage.setItem('users', JSON.stringify(users)); // 更新 Local Storage
    messageElement.textContent = "注册成功！请继续登录。";
}

// 等待文档加载完成后再添加事件监听器
window.onload = function() {
    document.getElementById('loginButton').addEventListener('click', login);
    document.getElementById('registerButton').addEventListener('click', register);
};

function changeBackground(imageUrl) {
    document.body.style.backgroundImage = `url('${imageUrl}')`;
}
// 显示随机运势的函数
function showRandomFortune() {
    const fortunes = ['大吉', '中吉', '中平', '凶'];
    const randomIndex = Math.floor(Math.random() * fortunes.length);
    alert("今天运势：" + fortunes[randomIndex]);
}

// 从 localStorage 获取用户信息
const users = JSON.parse(localStorage.getItem('users')) || [];

function authenticate(username) {
    return users.find(user => user.username === username);
}

function changePassword(username, newPassword) {
    const user = authenticate(username);
    if (user) {
        user.password = newPassword; // 修改密码
        localStorage.setItem('users', JSON.stringify(users)); // 更新 localStorage
        alert("密码修改成功！");
    } else {
        alert("用户不存在！");
    }
}

// DOM内容加载完成时运行的函数
document.addEventListener('DOMContentLoaded', function() {
    // 打卡按钮的事件监听
    document.getElementById('punchInButton').addEventListener('click', function() {
        showRandomFortune(); // 点击打卡按钮时显示随机运势
    });

    // 修改密码按钮的事件监听
    document.getElementById('changePasswordButton').addEventListener('click', function() {
        const username = document.getElementById('usernameInput').value.trim();
        const newPassword = document.getElementById('newPasswordInput').value.trim();
        const messageElement = document.getElementById('message');

        if (username === "" || newPassword === "") {
            messageElement.textContent = "用户名和新密码不能为空！";
            return;
        }

        changePassword(username, newPassword);
        document.getElementById('newPasswordInput').value = ""; // 清空新密码输入框
    });

    // 背景选择事件的监听
    document.getElementById('backgrounds').addEventListener('change', function() {
        changeBackground(this.value);
    });
});

function changeBackground(imageUrl) {
    document.body.style.backgroundImage = `url('${imageUrl}')`;
}
const users = [
    { username: '1', password: '1' },
];

function authenticate(username, password) {
    return users.some(user => user.username === username && user.password === password);
}

function checkLogin() {
    const username = document.getElementById('usernameInput').value.trim();
    const password = document.getElementById('passwordInput').value.trim();
    const messageElement = document.getElementById('message');

    if (username === "" || password === "") {
        messageElement.textContent = "用户名和密码不能为空！";
        return;
    }

    if (authenticate(username, password)) {
        messageElement.textContent = `欢迎，${username}！登录成功。`;
    } else {
        messageElement.textContent = "用户名或密码不正确，请重试。";
    }
}

// 等待文档加载完成后再添加事件监听器
window.onload = function() {
    document.getElementById('loginButton').addEventListener('click', checkLogin);
};
const signatureKey = "signature"; // 个性签名的存储键

function loadUserInfo() {
    // 从 localStorage 中读取用户名
    const currentUser = localStorage.getItem("username"); // 用户名存储在 localStorage 中


    // 读取个性签名
    const signature = localStorage.getItem(signatureKey) || "这个人很懒，还没有个性签名";
    document.getElementById('signature').value = signature;
}

function saveSignature() {
    const newSignature = document.getElementById('signature').value;
    if (newSignature.trim() === "") {
        alert("个性签名不能为空！");
        return;
    }
    localStorage.setItem(signatureKey, newSignature);
    alert("个性签名已更新！");
}

window.onload = loadUserInfo; // 页面加载时加载用户信息
window.onload = function() {
    const pageHeight = document.body.scrollHeight;
    document.body.style.backgroundImage = `url('your-image.jpg')`;
    document.body.style.backgroundSize = `cover`;
    document.body.style.backgroundRepeat = `no-repeat`;
    document.body.style.backgroundPosition = `center`;
    document.body.style.height = `${pageHeight}px`;
};